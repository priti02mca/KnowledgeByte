using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVCApp.Models;
using System.Reflection;

using System.Runtime.Loader;
using System.IO;

namespace MVCApp.Controllers
{
    public class AddressesController : Controller
    {
        private readonly MVCAppContext _context;

        public AddressesController(MVCAppContext context)
        {
            _context = context;
        }

        // GET: Addresses
        public async Task<IActionResult> Index()
        {
            try
            {
                ViewData["Error"] = string.Empty;
                var addressList = new List<Address>();
                dynamic result = new object();
                var callingProvider = false;
                foreach (String dll in Directory.GetFiles(Directory.GetCurrentDirectory() + Path.GetDirectoryName("/bin/"), "*.dll"))
                {
                    callingProvider = true;
                    var myType = loadAssemblyAndGetType(dll);
                    if (myType != null)
                    {
                        MethodInfo methodInfo = myType.GetMethod("getAddressData");
                        if (methodInfo != null)
                        {

                            object classInstance = Activator.CreateInstance(myType, null);
                            result = methodInfo.Invoke(classInstance, null);
                            if (result.Count > 0)
                            {
                                return View(getAddressListFromResult(result));

                            }
                        }

                        return View(addressList);

                    }
                    ViewData["Msg"] = "Plugin assembly is not present in bin folder.";
                    return View(new List<Address>());
                }

                // SqlProvide code is not moved to different project so below code is used to get data from sql server.
                if (callingProvider == false)
                {
                    return View(await _context.Address.ToListAsync());
                }

                return View(addressList);

            }
            catch(Exception ex)
            {
                ViewData["Msg"] = ex.Message.ToString();
                return View(new List<Models.Address>());
                //throw;
            }
            
        }


        // GET: Addresses/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST : Addresses/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AddressID,FirstName,LastName,Street,Zip,City,Country")] Address address)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ViewData["Error"] = string.Empty;
                    dynamic result = new object();
                    var callingProvider = false;


                    foreach (string dll in Directory.GetFiles(Directory.GetCurrentDirectory() + Path.GetDirectoryName("/bin/"), "*.dll"))
                    {
                        callingProvider = true;
                        var myType = loadAssemblyAndGetType(dll);
                        if (myType != null)
                        {
                            MethodInfo methodInfo = myType.GetMethod("AddAddress");
                            if (methodInfo != null)
                            {
                                ParameterInfo[] parameters = methodInfo.GetParameters();
                                object classInstance = Activator.CreateInstance(myType, null);
                                object[] parametersArray = new object[] { address };
                                result = methodInfo.Invoke(classInstance, parametersArray);
                                return RedirectToAction("Index");
                            }
                        }
                        ViewData["Msg"] = "Plugin assembly is not present in bin folder.";
                        return RedirectToAction("Index");
                    }

                    // SqlProvide code is not moved to different project so below code is used to save data into sql server database.
                    if (callingProvider == false)
                    {
                        _context.Add(address);
                        await _context.SaveChangesAsync();
                        return RedirectToAction("Index");
                    }
                }
                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {
                ViewData["Msg"] = ex.Message.ToString();
                return RedirectToAction("Index");
            }

        }

        [HttpPost]
        public async Task<IActionResult> Search(string search)
        {
            try
            {
                ViewData["Msg"] = string.Empty;
                var addressList = new List<Address>();
                dynamic result = new object();
                dynamic myType;
                var callingProvider = false;
                foreach (string dll in Directory.GetFiles(Directory.GetCurrentDirectory() + Path.GetDirectoryName("/bin/"), "*.dll"))
                {
                    callingProvider = true;
                    myType = loadAssemblyAndGetType(dll);
                    if (myType != null)
                    {
                        MethodInfo methodInfo = myType.GetMethod("SearchAddress");
                        if (methodInfo != null)
                        {
                            ParameterInfo[] parameters = methodInfo.GetParameters();
                            object classInstance = Activator.CreateInstance(myType, null);
                            object[] parametersArray = new object[] { search };
                            result = methodInfo.Invoke(classInstance, parametersArray);
                            if (result.Count > 0)
                            {
                                addressList = getAddressListFromResult(result);
                            }
                        }
                        return View("Index", addressList);
                    }
                }

                // SqlProvide code is not moved to different project so below code is used to perform search into sql server database table.
                if (callingProvider == false)
                {
                    if (String.IsNullOrEmpty(search))
                    {
                        return View("Index", await _context.Address.ToListAsync());
                    }
                    else
                    {
                        var searchedResult = _context.Address.Where(t => t.FirstName.Contains(search.Trim()) ||
                                                        t.LastName.Contains(search.Trim())).ToList();

                        return View("Index", searchedResult);
                    }
                }

                ViewData["Msg"] = "Plugin is not exist in bin folder.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewData["Msg"] = ex.Message.ToString();
                return RedirectToAction("Index");
            }
        }

        // convert json libary object to model object
        private List<Address> getAddressListFromResult(dynamic result)
        {
            var addressList = new List<Address>();
            foreach (var data in result)
            {
                var addr = new Address();
                addr.FirstName = data.FirstName;
                addr.LastName = data.LastName;
                addr.Street = data.Street;
                addr.Zip = data.Zip;
                addr.City = data.City;
                addr.Country = data.Country;

                addressList.Add(addr);
            }
            return addressList;
        }

        //Generalized methode to find the used Provider name (Json provider or sqlprovider)
        private dynamic loadAssemblyAndGetType(string path)
        {
            Assembly plugIn = AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
            var plugInName = plugIn.GetName().Name;
            if (plugInName == "JsonProvider")
            {
                return plugIn.GetType("JsonProvider.JsonFile");
            }
            else if(plugInName == "SQLProvider")
            {
                return plugIn.GetType("SQLProvider.SQLFile");
            }
            return null;
        }
    }
}
