﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace MVCApp.Models
{
    public class MVCAppContext : DbContext
    {
        public MVCAppContext (DbContextOptions<MVCAppContext> options)
            : base(options)
        {
        }

        public DbSet<MVCApp.Models.Address> Address { get; set; }
    }
}
