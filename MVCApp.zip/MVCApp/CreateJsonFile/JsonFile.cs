﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using Newtonsoft.Json;


namespace JsonProvider
{
    public class JsonFile
    {
        // method for getting data from json file
        public List<Address> getAddressData()
        {
            var file = File.Exists(@"C:\temp\address.json") ? true : false;
            if (file == false)
            {
                File.Create(@"C:\temp\address.json");
                System.Threading.Thread.Sleep(10000);
            }

            var jsonData = File.ReadAllText(@"C:\temp\address.json");
            var addressList = JsonConvert.DeserializeObject<List<Address>>(jsonData)
                      ?? new List<Address>();

            return addressList;
        }

        //Method for add address deatils to jason file
        public void AddAddress(dynamic address)
        {
            var file = File.Exists(@"C:\temp\address.json") ? true : false;
            if (file == false)
            {
                File.Create(@"C:\temp\address.json");
                System.Threading.Thread.Sleep(10000);
            }

            var jsonData = File.ReadAllText(@"C:\temp\address.json");
            var addressList = JsonConvert.DeserializeObject<List<Address>>(jsonData)
                      ?? new List<Address>();
            var newAddress = new Address();
            newAddress.FirstName = address.FirstName;
            newAddress.LastName = address.LastName;
            newAddress.Street = address.Street;
            newAddress.Zip = address.Zip;
            newAddress.City = address.City;
            newAddress.Country = address.Country;
            addressList.Add(newAddress);

            string json = JsonConvert.SerializeObject(addressList);

            File.WriteAllText(@"C:\temp\address.json", json);
        }

        // Perform seach on jsondata
        public List<Address> SearchAddress(string search)
        {
            var file = File.Exists(@"C:\temp\address.json") ? true : false;
            if (file == false)
            {
                File.Create(@"C:\temp\address.json");
                System.Threading.Thread.Sleep(10000);
            }

            var addrList = new List<Address>();
            var jsonData = File.ReadAllText(@"C:\temp\address.json");
            var addressList = JsonConvert.DeserializeObject<List<Address>>(jsonData)
                      ?? new List<Address>();
            if (!String.IsNullOrEmpty(search))
            {
                var searchedResult = (from a in addressList
                                      where a.FirstName.ToUpper() == search.ToUpper().Trim()
                                         || a.LastName.ToUpper() == search.ToUpper().Trim()
                                      select a).ToList();

                addrList = searchedResult.Count == 0 ? new List<Address>() : searchedResult;
                return addrList;
            }
            else
            {
                return addressList;
            }
            
        }

    }
}
