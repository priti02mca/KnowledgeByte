﻿using System;

namespace CreateJsonFile
{
    public class Class1
    {
    }
}
